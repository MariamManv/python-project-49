### Hexlet tests and linter status:
[![Actions Status](https://github.com/MariamManv/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/MariamManv/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/17116551a20b390f4e4f/maintainability)](https://codeclimate.com/github/MariamManv/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/GHKletbAnVTg4EgjeXrYLjEgJ.svg)](https://asciinema.org/a/GHKletbAnVTg4EgjeXrYLjEgJ)
